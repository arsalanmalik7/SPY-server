
const validDishTypes = [
  "Appetizer",
  "Main",
  "Dessert",
  "Pizza",
  "Pasta",
  "Sandwich/Wrap",
  "Salad",
  "Soup",
  "Entrée",
  "Special",
  "Side",

]
export default validDishTypes;

