const temperatureOptions = ["Cold", "Room Temperature", "Warm", "Hot"];

export default temperatureOptions;
