const accommodationOptions = {
  validAccommodations: [
    "Vegan",
    "Vegetarian",
    "Gluten-Free",
    "Dairy-Free",
    "Nut-Free",
    "Soy-Free",
    "Sesame-Free"
  ]
};

export default accommodationOptions;