const wineCategories = [
  "Red",
  "White",
  "Sparkling",
  "Rose",
  "Dessert",
  "Orange",
];

export default wineCategories;