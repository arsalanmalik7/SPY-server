// Update restaurant wine customization
router.put('/:restaurantId/wines/:wineId/customization', auth, restaurantWineController.updateRestaurantWineCustomization); 